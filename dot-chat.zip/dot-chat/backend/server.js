const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 16) {
  console.error('Set JWT_SECRET to a long random string (16+ chars).');
  process.exit(1);
}
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : false,
});

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '50kb' }));

// tiny in-memory rate limit for auth endpoints
const hits = new Map();
function limit(req, res, next) {
  const now = Date.now();
  const arr = (hits.get(req.ip) || []).filter((t) => now - t < 60000);
  if (arr.length >= 20) return res.status(429).json({ error: 'Too many attempts, try again in a minute' });
  arr.push(now);
  hits.set(req.ip, arr);
  next();
}

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const sign = (u) => jwt.sign({ id: u.id, email: u.email }, JWT_SECRET, { expiresIn: '90d' });

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  try {
    req.user = jwt.verify(h.replace(/^Bearer /, ''), JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Unauthorized' });
  }
}

app.get('/', (_, res) => res.json({ ok: true, name: 'dot-server' }));

app.post('/register', limit, async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!emailRe.test(email)) return res.status(400).json({ error: 'Enter a valid email' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  try {
    const hash = await bcrypt.hash(password, 10);
    const r = await pool.query('INSERT INTO users(email, password_hash) VALUES($1,$2) RETURNING id, email', [email, hash]);
    res.json({ token: sign(r.rows[0]), email });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Email already registered' });
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/login', limit, async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  try {
    const r = await pool.query('SELECT id, email, password_hash FROM users WHERE email=$1', [email]);
    const u = r.rows[0];
    if (!u || !(await bcrypt.compare(password, u.password_hash))) {
      return res.status(401).json({ error: 'Wrong email or password' });
    }
    res.json({ token: sign(u), email: u.email });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/users/exists', auth, async (req, res) => {
  const email = String(req.query.email || '').trim().toLowerCase();
  const r = await pool.query('SELECT 1 FROM users WHERE email=$1', [email]);
  res.json({ exists: r.rowCount > 0 });
});

// realtime
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });
const online = new Map(); // email -> Set<ws>

server.on('upgrade', (req, socket, head) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname !== '/ws') throw new Error('bad path');
    const user = jwt.verify(url.searchParams.get('token') || '', JWT_SECRET);
    wss.handleUpgrade(req, socket, head, (ws) => {
      ws.user = user;
      wss.emit('connection', ws);
    });
  } catch {
    socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
    socket.destroy();
  }
});

function pushTo(email, obj) {
  const set = online.get(email);
  if (!set) return false;
  const s = JSON.stringify(obj);
  set.forEach((w) => w.readyState === 1 && w.send(s));
  return set.size > 0;
}
const toMsg = (m) => ({ type: 'message', id: m.id, from: m.sender, to: m.recipient, body: m.body, ts: new Date(m.created_at).getTime() });

wss.on('connection', async (ws) => {
  const me = ws.user.email;
  if (!online.has(me)) online.set(me, new Set());
  online.get(me).add(ws);
  ws.isAlive = true;
  ws.on('pong', () => (ws.isAlive = true));

  try {
    const pending = await pool.query('SELECT * FROM messages WHERE recipient=$1 AND delivered_at IS NULL ORDER BY created_at LIMIT 500', [me]);
    pending.rows.forEach((m) => ws.send(JSON.stringify(toMsg(m))));
    const rc = await pool.query(
      "SELECT id, delivered_at, read_at FROM messages WHERE sender=$1 AND created_at > now() - interval '7 days' AND delivered_at IS NOT NULL",
      [me]
    );
    rc.rows.forEach((m) => ws.send(JSON.stringify({ type: 'receipt', id: m.id, status: m.read_at ? 3 : 2 })));
  } catch (e) {
    console.error(e);
  }

  ws.on('message', async (raw) => {
    let j;
    try { j = JSON.parse(raw.toString()); } catch { return; }
    try {
      if (j.type === 'send') {
        const id = String(j.id || '').slice(0, 64);
        const to = String(j.to || '').trim().toLowerCase();
        const body = String(j.body || '').slice(0, 4000);
        if (!id || !body || to === me) return;
        const u = await pool.query('SELECT 1 FROM users WHERE email=$1', [to]);
        if (!u.rowCount) return;
        const ins = await pool.query(
          'INSERT INTO messages(id, sender, recipient, body) VALUES($1,$2,$3,$4) ON CONFLICT (id) DO NOTHING RETURNING *',
          [id, me, to, body]
        );
        ws.send(JSON.stringify({ type: 'sent', id }));
        if (ins.rowCount) pushTo(to, toMsg(ins.rows[0]));
      } else if (j.type === 'delivered') {
        const r = await pool.query(
          'UPDATE messages SET delivered_at = now() WHERE id=$1 AND recipient=$2 AND delivered_at IS NULL RETURNING sender, id',
          [String(j.id), me]
        );
        r.rows.forEach((m) => pushTo(m.sender, { type: 'receipt', id: m.id, status: 2 }));
      } else if (j.type === 'read' && Array.isArray(j.ids)) {
        const ids = j.ids.slice(0, 200).map(String);
        const r = await pool.query(
          'UPDATE messages SET read_at = now(), delivered_at = COALESCE(delivered_at, now()) WHERE id = ANY($1) AND recipient=$2 AND read_at IS NULL RETURNING sender, id',
          [ids, me]
        );
        r.rows.forEach((m) => pushTo(m.sender, { type: 'receipt', id: m.id, status: 3 }));
      }
    } catch (e) {
      console.error(e);
    }
  });

  ws.on('close', () => {
    const set = online.get(me);
    if (set) { set.delete(ws); if (!set.size) online.delete(me); }
  });
});

setInterval(() => {
  wss.clients.forEach((w) => {
    if (!w.isAlive) return w.terminate();
    w.isAlive = false;
    w.ping();
  });
}, 30000);

(async () => {
  await pool.query(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
  server.listen(PORT, () => console.log('dot-server listening on ' + PORT));
})().catch((e) => { console.error('Startup failed:', e.message); process.exit(1); });
