package app.dot.chat

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// status: 0 sending, 1 sent, 2 delivered, 3 read
@Entity(tableName = "messages", indices = [Index("peer")])
data class Msg(
    @PrimaryKey val id: String,
    val peer: String,
    val mine: Boolean,
    val body: String,
    val ts: Long,
    val status: Int
)

data class Conv(val peer: String, val lastBody: String, val lastTs: Long, val unread: Int)

@Dao
interface MsgDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(m: Msg): Long

    @Query("SELECT * FROM messages WHERE peer = :peer ORDER BY ts ASC")
    fun chat(peer: String): Flow<List<Msg>>

    @Query(
        "SELECT peer, body AS lastBody, MAX(ts) AS lastTs, " +
            "SUM(CASE WHEN mine = 0 AND status < 3 THEN 1 ELSE 0 END) AS unread " +
            "FROM messages GROUP BY peer ORDER BY lastTs DESC"
    )
    fun convs(): Flow<List<Conv>>

    @Query("UPDATE messages SET status = :s WHERE id = :id AND status < :s")
    suspend fun upgrade(id: String, s: Int)

    @Query("SELECT id FROM messages WHERE peer = :peer AND mine = 0 AND status < 3")
    suspend fun unreadIds(peer: String): List<String>

    @Query("UPDATE messages SET status = 3 WHERE peer = :peer AND mine = 0 AND status < 3")
    suspend fun markRead(peer: String)

    @Query("SELECT * FROM messages WHERE mine = 1 AND status = 0 ORDER BY ts ASC")
    suspend fun unsent(): List<Msg>

    @Query("DELETE FROM messages")
    suspend fun clear()
}

@Database(entities = [Msg::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MsgDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "dot.db")
                .build().also { inst = it }
        }
    }
}
