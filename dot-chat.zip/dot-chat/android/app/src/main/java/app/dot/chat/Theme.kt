package app.dot.chat

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

val SeedColors = listOf(
    0xFFD71921, 0xFF2979FF, 0xFF00C896, 0xFF8E5BFF,
    0xFFFFB300, 0xFFFF4D8D, 0xFFB6F500, 0xFFE0E0E0
).map { it.toInt() }

private fun schemeFromSeed(seed: Color, dark: Boolean): ColorScheme {
    val base = if (dark) Color(0xFF0A0A0A) else Color(0xFFF4F4F4)
    val ink = if (dark) Color(0xFFF2F2F2) else Color(0xFF111111)
    val primary = if (dark) lerp(seed, Color.White, 0.2f) else lerp(seed, Color.Black, 0.1f)
    val onPrimary = if (primary.luminance() > 0.5f) Color.Black else Color.White
    val container = lerp(base, seed, if (dark) 0.35f else 0.22f)
    val soft = lerp(base, seed, 0.1f)
    val start = if (dark) darkColorScheme() else lightColorScheme()
    return start.copy(
        primary = primary, onPrimary = onPrimary,
        primaryContainer = container, onPrimaryContainer = ink,
        secondary = primary, onSecondary = onPrimary,
        secondaryContainer = soft, onSecondaryContainer = ink,
        background = base, onBackground = ink,
        surface = lerp(base, ink, 0.05f), onSurface = ink,
        surfaceVariant = lerp(base, ink, 0.10f),
        onSurfaceVariant = lerp(ink, base, 0.35f),
        outline = lerp(base, ink, 0.40f)
    )
}

private val mono = FontFamily.Monospace
private val DotTypography = Typography().let { t ->
    t.copy(
        displayMedium = t.displayMedium.copy(fontFamily = mono, fontWeight = FontWeight.Bold),
        headlineMedium = t.headlineMedium.copy(fontFamily = mono, fontWeight = FontWeight.Bold),
        titleLarge = t.titleLarge.copy(fontFamily = mono, fontWeight = FontWeight.Bold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = t.labelLarge.copy(fontFamily = mono),
        labelSmall = t.labelSmall.copy(fontFamily = mono)
    )
}

@Composable
fun DotTheme(content: @Composable () -> Unit) {
    val dark = when (Prefs.mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val scheme = if (Prefs.dynamic && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else schemeFromSeed(Color(Prefs.seed), dark)
    val shapes = if (Prefs.square) {
        val s = RoundedCornerShape(0.dp)
        Shapes(s, s, s, s, s)
    } else {
        Shapes(
            extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp), large = RoundedCornerShape(26.dp),
            extraLarge = RoundedCornerShape(36.dp)
        )
    }
    MaterialTheme(colorScheme = scheme, shapes = shapes, typography = DotTypography, content = content)
}

@Composable
fun glassColor(extra: Float = 0f): Color =
    MaterialTheme.colorScheme.surface.copy(alpha = (Prefs.glass + extra).coerceIn(0f, 1f))

fun avatarShape(): Shape = if (Prefs.square) RectangleShape else CircleShape
