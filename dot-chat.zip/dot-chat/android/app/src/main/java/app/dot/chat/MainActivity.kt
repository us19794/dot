package app.dot.chat

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private var pendingPeer by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        pendingPeer = intent.getStringExtra("peer")
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            DotTheme { App(pendingPeer) { pendingPeer = null } }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pendingPeer = intent.getStringExtra("peer")
    }

    override fun onStart() {
        super.onStart()
        ChatClient.foreground = true
        ChatClient.start(this)
    }

    override fun onStop() {
        super.onStop()
        ChatClient.foreground = false
    }
}

@Composable
fun App(pendingPeer: String?, consumePeer: () -> Unit) {
    var peer by remember { mutableStateOf<String?>(null) }
    var settings by remember { mutableStateOf(false) }

    if (Prefs.token.isEmpty()) {
        AuthScreen()
        return
    }
    LaunchedEffect(pendingPeer) {
        if (pendingPeer != null) { peer = pendingPeer; consumePeer() }
    }
    BackHandler(enabled = settings || peer != null) {
        if (settings) settings = false else peer = null
    }
    val key = if (settings) "settings" else peer ?: "list"
    Crossfade(targetState = key, label = "nav") { k ->
        when (k) {
            "settings" -> SettingsScreen(onBack = { settings = false })
            "list" -> ListScreen(onOpen = { peer = it }, onSettings = { settings = true })
            else -> ChatScreen(k, onBack = { peer = null })
        }
    }
}
