package app.dot.chat

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Prefs {
    private lateinit var sp: SharedPreferences

    var server by mutableStateOf("")
    var token by mutableStateOf("")
    var email by mutableStateOf("")
    var seed by mutableStateOf(0xFFD71921.toInt())
    var mode by mutableStateOf(2)            // 0 system, 1 light, 2 dark
    var dynamic by mutableStateOf(false)     // Material You colours (Android 12+)
    var square by mutableStateOf(false)      // square or rounded corners
    var wallpaper by mutableStateOf("dots")  // plain, dots, grid, aurora, image
    var wallpaperVersion by mutableStateOf(0)
    var wallpaperBlur by mutableStateOf(0f)  // 0..25
    var glass by mutableStateOf(0.55f)       // bar / bubble opacity 0.2..1

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.applicationContext.getSharedPreferences("dot", Context.MODE_PRIVATE)
        server = sp.getString("server", "") ?: ""
        token = sp.getString("token", "") ?: ""
        email = sp.getString("email", "") ?: ""
        seed = sp.getInt("seed", seed)
        mode = sp.getInt("mode", mode)
        dynamic = sp.getBoolean("dynamic", dynamic)
        square = sp.getBoolean("square", square)
        wallpaper = sp.getString("wallpaper", wallpaper) ?: "dots"
        wallpaperVersion = sp.getInt("wpv", 0)
        wallpaperBlur = sp.getFloat("blur", wallpaperBlur)
        glass = sp.getFloat("glass", glass)
    }

    fun update(block: Prefs.() -> Unit) {
        block()
        sp.edit()
            .putString("server", server).putString("token", token).putString("email", email)
            .putInt("seed", seed).putInt("mode", mode).putBoolean("dynamic", dynamic)
            .putBoolean("square", square).putString("wallpaper", wallpaper)
            .putInt("wpv", wallpaperVersion).putFloat("blur", wallpaperBlur).putFloat("glass", glass)
            .apply()
    }
}
