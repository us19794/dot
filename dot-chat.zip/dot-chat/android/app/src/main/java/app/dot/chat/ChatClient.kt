package app.dot.chat

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

object Api {
    private val http = OkHttpClient()
    private val json = "application/json".toMediaType()

    suspend fun auth(server: String, path: String, email: String, password: String): Result<Pair<String, String>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val body = JSONObject().put("email", email).put("password", password)
                    .toString().toRequestBody(json)
                val req = Request.Builder().url(server.trimEnd('/') + path).post(body).build()
                http.newCall(req).execute().use { r ->
                    val j = JSONObject(r.body?.string() ?: "{}")
                    if (!r.isSuccessful) error(j.optString("error", "Error ${r.code}"))
                    j.getString("token") to j.getString("email")
                }
            }
        }

    suspend fun exists(email: String): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val url = Prefs.server.trimEnd('/') + "/users/exists?email=" + java.net.URLEncoder.encode(email, "UTF-8")
            val req = Request.Builder().url(url).header("Authorization", "Bearer " + Prefs.token).build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("Server error ${r.code}")
                JSONObject(r.body?.string() ?: "{}").optBoolean("exists", false)
            }
        }
    }
}

object Notifier {
    fun show(ctx: Context, peer: String, body: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("msgs", "Messages", NotificationManager.IMPORTANCE_HIGH))
        val intent = Intent(ctx, MainActivity::class.java)
            .putExtra("peer", peer).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            ctx, peer.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, "msgs")
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(peer).setContentText(body)
            .setAutoCancel(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        nm.notify(peer.hashCode(), n)
    }
}

object ChatClient {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http = OkHttpClient.Builder()
        .pingInterval(25, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()
    private var ws: WebSocket? = null
    private var job: Job? = null
    private lateinit var app: Context

    val connected = MutableStateFlow(false)
    @Volatile var openPeer: String? = null
    @Volatile var foreground = false

    fun start(ctx: Context) {
        app = ctx.applicationContext
        if (job?.isActive == true || Prefs.token.isEmpty() || Prefs.server.isEmpty()) return
        job = scope.launch {
            var backoff = 1000L
            while (isActive) {
                val closed = CompletableDeferred<Unit>()
                val url = Prefs.server.trimEnd('/').replaceFirst("http", "ws") + "/ws?token=" + Prefs.token
                val req = try { Request.Builder().url(url).build() } catch (e: Exception) { delay(5000); continue }
                ws = http.newWebSocket(req, object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        connected.value = true
                        backoff = 1000L
                        scope.launch { flushUnsent() }
                    }
                    override fun onMessage(webSocket: WebSocket, text: String) {
                        scope.launch { handle(text) }
                    }
                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                        connected.value = false; closed.complete(Unit)
                    }
                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        connected.value = false
                        if (response?.code == 401) Prefs.update { token = "" }
                        closed.complete(Unit)
                    }
                })
                closed.await()
                if (Prefs.token.isEmpty()) break
                delay(backoff)
                backoff = (backoff * 2).coerceAtMost(30000L)
            }
        }
    }

    fun stop() {
        job?.cancel(); job = null
        ws?.close(1000, null); ws = null
        connected.value = false
    }

    private fun send(o: JSONObject): Boolean = ws?.send(o.toString()) ?: false

    private suspend fun flushUnsent() {
        AppDb.get(app).dao().unsent().forEach { m ->
            send(JSONObject().put("type", "send").put("id", m.id).put("to", m.peer).put("body", m.body))
        }
    }

    fun sendText(peer: String, body: String) {
        scope.launch {
            val m = Msg(UUID.randomUUID().toString(), peer, true, body, System.currentTimeMillis(), 0)
            AppDb.get(app).dao().insert(m)
            if (connected.value) {
                send(JSONObject().put("type", "send").put("id", m.id).put("to", peer).put("body", body))
            }
        }
    }

    fun markRead(peer: String) {
        scope.launch {
            val dao = AppDb.get(app).dao()
            val ids = dao.unreadIds(peer)
            if (ids.isEmpty()) return@launch
            dao.markRead(peer)
            send(JSONObject().put("type", "read").put("ids", JSONArray(ids)))
        }
    }

    private suspend fun handle(text: String) {
        val j = JSONObject(text)
        val dao = AppDb.get(app).dao()
        when (j.getString("type")) {
            "message" -> {
                val m = Msg(j.getString("id"), j.getString("from"), false, j.getString("body"), j.getLong("ts"), 2)
                val fresh = dao.insert(m) != -1L
                send(JSONObject().put("type", "delivered").put("id", m.id))
                if (fresh) {
                    if (foreground && openPeer == m.peer) {
                        dao.upgrade(m.id, 3)
                        send(JSONObject().put("type", "read").put("ids", JSONArray(listOf(m.id))))
                    } else {
                        Notifier.show(app, m.peer, m.body)
                    }
                }
            }
            "sent" -> dao.upgrade(j.getString("id"), 1)
            "receipt" -> dao.upgrade(j.getString("id"), j.getInt("status"))
        }
    }
}
