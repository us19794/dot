package app.dot.chat

import android.graphics.BitmapFactory
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
private fun rememberWallpaperBitmap(version: Int): ImageBitmap? {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, version) {
        value = withContext(Dispatchers.IO) {
            val f = File(ctx.filesDir, "wallpaper.img")
            if (!f.exists()) null else {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, bounds)
                var s = 1
                while (bounds.outWidth / (s * 2) >= 1080 && bounds.outHeight / (s * 2) >= 1080) s *= 2
                BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
                    ?.asImageBitmap()
            }
        }
    }
    return bmp
}

@Composable
fun Wallpaper(modifier: Modifier = Modifier.fillMaxSize(), blurOverride: Float? = null) {
    val cs = MaterialTheme.colorScheme
    val radius = blurOverride ?: Prefs.wallpaperBlur
    val blurMod = if (Build.VERSION.SDK_INT >= 31 && radius > 0f) Modifier.blur(radius.dp) else Modifier
    Box(modifier.background(cs.background)) {
        Box(Modifier.fillMaxSize().then(blurMod)) {
            when (Prefs.wallpaper) {
                "image" -> {
                    val bmp = rememberWallpaperBitmap(Prefs.wallpaperVersion)
                    if (bmp != null) {
                        Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    }
                }
                "dots" -> {
                    val c = cs.primary.copy(alpha = 0.22f)
                    Canvas(Modifier.fillMaxSize()) {
                        val step = 26.dp.toPx()
                        var y = step / 2
                        while (y < size.height) {
                            var x = step / 2
                            while (x < size.width) {
                                drawCircle(c, 1.7.dp.toPx(), Offset(x, y))
                                x += step
                            }
                            y += step
                        }
                    }
                }
                "grid" -> {
                    val c = cs.onSurface.copy(alpha = 0.07f)
                    Canvas(Modifier.fillMaxSize()) {
                        val step = 40.dp.toPx()
                        var x = 0f
                        while (x < size.width) { drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f); x += step }
                        var y = 0f
                        while (y < size.height) { drawLine(c, Offset(0f, y), Offset(size.width, y), 1f); y += step }
                    }
                }
                "aurora" -> {
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.linearGradient(
                                listOf(cs.primary.copy(alpha = 0.45f), cs.background, cs.primaryContainer.copy(alpha = 0.6f))
                            )
                        )
                    )
                }
                else -> {}
            }
        }
    }
}

/** Frosted bar: a blurred slice of the wallpaper plus a translucent tint. */
@Composable
fun Frosted(top: Boolean, content: @Composable () -> Unit) {
    val cfg = LocalConfiguration.current
    Box(Modifier.fillMaxWidth().clipToBounds()) {
        Box(Modifier.matchParentSize()) {
            Wallpaper(
                Modifier
                    .align(if (top) Alignment.TopStart else Alignment.BottomStart)
                    .requiredSize(cfg.screenWidthDp.dp, cfg.screenHeightDp.dp),
                blurOverride = 30f
            )
        }
        Box(Modifier.matchParentSize().background(glassColor()))
        content()
    }
}
