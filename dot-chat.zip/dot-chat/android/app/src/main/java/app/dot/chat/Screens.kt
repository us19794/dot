package app.dot.chat

import android.os.Build
import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmtTime(ts: Long): String =
    SimpleDateFormat(if (DateUtils.isToday(ts)) "HH:mm" else "d MMM", Locale.getDefault()).format(Date(ts))

@Composable
private fun Logo(style: androidx.compose.ui.text.TextStyle) {
    Text(
        buildAnnotatedString {
            append("dot")
            withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary)) { append(".") }
        },
        style = style
    )
}

@Composable
fun Avatar(peer: String, size: Dp) {
    Box(
        Modifier.size(size).clip(avatarShape()).background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Text(
            peer.take(1).uppercase(), style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
    }
}

// ───────────────────────── Auth ─────────────────────────

@Composable
fun AuthScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var srv by remember { mutableStateOf(Prefs.server) }
    var mail by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize()) {
        Wallpaper()
        Box(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding(),
            contentAlignment = Alignment.Center
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp)) {
                Logo(MaterialTheme.typography.displayMedium)
                Text(
                    "Messages. Nothing more.", style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.size(28.dp))
                Surface(shape = MaterialTheme.shapes.extraLarge, color = glassColor(0.15f)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            srv, { srv = it }, Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text("Server URL") }, placeholder = { Text("https://your-server.com") },
                            shape = MaterialTheme.shapes.medium,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                        )
                        OutlinedTextField(
                            mail, { mail = it }, Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text("Email") }, shape = MaterialTheme.shapes.medium,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                        )
                        OutlinedTextField(
                            pass, { pass = it }, Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text("Password") }, shape = MaterialTheme.shapes.medium,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
                        Button(
                            onClick = {
                                val server = srv.trim()
                                if (server.isEmpty() || mail.isBlank() || pass.isEmpty()) {
                                    error = "Fill in all fields"; return@Button
                                }
                                loading = true; error = null
                                scope.launch {
                                    Api.auth(server, if (register) "/register" else "/login", mail.trim().lowercase(), pass)
                                        .onSuccess { (t, e) ->
                                            Prefs.update { this.server = server; token = t; email = e }
                                            ChatClient.start(ctx)
                                        }
                                        .onFailure { error = it.message ?: "Something went wrong" }
                                    loading = false
                                }
                            },
                            enabled = !loading, modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large
                        ) { Text(if (loading) "…" else if (register) "Create account" else "Log in") }
                        TextButton(onClick = { register = !register; error = null }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                            Text(if (register) "Have an account? Log in" else "New here? Create account")
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Chat list ─────────────────────────

@Composable
fun ListScreen(onOpen: (String) -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    val convs by dao.convs().collectAsState(initial = emptyList())
    val connected by ChatClient.connected.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Wallpaper()
        Column(Modifier.fillMaxSize()) {
            Frosted(top = true) {
                Row(
                    Modifier.statusBarsPadding().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Logo(MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier.size(8.dp).clip(CircleShape)
                            .background(if (connected) Color(0xFF3DDC84) else MaterialTheme.colorScheme.error)
                    )
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Settings") }
                }
            }
            if (convs.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(
                        "No chats yet.\nTap + to start one.", textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    Modifier.weight(1f), contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(convs, key = { it.peer }) { c -> ConvRow(c) { onOpen(c.peer) } }
                }
            }
        }
        FloatingActionButton(
            onClick = { showNew = true },
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(20.dp),
            shape = MaterialTheme.shapes.large
        ) { Icon(Icons.Filled.Add, "New chat") }
    }
    if (showNew) NewChatDialog(onDismiss = { showNew = false }, onOpen = { showNew = false; onOpen(it) })
}

@Composable
private fun ConvRow(c: Conv, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = MaterialTheme.shapes.large, color = glassColor(0.1f)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(c.peer, 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(c.peer, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    c.lastBody, style = MaterialTheme.typography.bodyMedium, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(fmtTime(c.lastTs), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (c.unread > 0) {
                    Spacer(Modifier.size(4.dp))
                    Badge { Text(c.unread.toString()) }
                }
            }
        }
    }
}

@Composable
private fun NewChatDialog(onDismiss: () -> Unit, onOpen: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var mail by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        title = { Text("New chat") },
        text = {
            Column {
                OutlinedTextField(
                    mail, { mail = it }, singleLine = true, label = { Text("Their email") },
                    shape = MaterialTheme.shapes.medium,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val v = mail.trim().lowercase()
                if (v.isEmpty()) return@TextButton
                if (v == Prefs.email) { err = "That's you"; return@TextButton }
                busy = true; err = null
                scope.launch {
                    Api.exists(v)
                        .onSuccess { if (it) onOpen(v) else err = "No account with that email" }
                        .onFailure { err = it.message ?: "Couldn't reach server" }
                    busy = false
                }
            }) { Text("Start") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ───────────────────────── Chat ─────────────────────────

@Composable
fun ChatScreen(peer: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    val msgs by dao.chat(peer).collectAsState(initial = emptyList())
    val connected by ChatClient.connected.collectAsState()
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    DisposableEffect(peer) {
        ChatClient.openPeer = peer
        onDispose { ChatClient.openPeer = null }
    }
    LaunchedEffect(peer, msgs.size) {
        ChatClient.markRead(peer)
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex)
    }

    Box(Modifier.fillMaxSize()) {
        Wallpaper()
        Column(Modifier.fillMaxSize()) {
            Frosted(top = true) {
                Row(
                    Modifier.statusBarsPadding().padding(horizontal = 4.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    Avatar(peer, 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(peer, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (connected) "connected" else "connecting…",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            LazyColumn(
                state = listState, modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(msgs, key = { it.id }) { Bubble(it) }
            }
            Frosted(top = false) {
                Row(
                    Modifier.navigationBarsPadding().imePadding().padding(8.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    val field = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
                    TextField(
                        value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Message") }, maxLines = 5, shape = MaterialTheme.shapes.large,
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            focusedContainerColor = field, unfocusedContainerColor = field
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(
                        onClick = {
                            val t = text.trim()
                            if (t.isNotEmpty()) { ChatClient.sendText(peer, t); text = "" }
                        },
                        modifier = Modifier.size(52.dp), shape = avatarShape()
                    ) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
                }
            }
        }
    }
}

@Composable
private fun Bubble(m: Msg) {
    val cs = MaterialTheme.colorScheme
    val shape: Shape = if (Prefs.square) RectangleShape else RoundedCornerShape(
        topStart = 22.dp, topEnd = 22.dp,
        bottomStart = if (m.mine) 22.dp else 4.dp, bottomEnd = if (m.mine) 4.dp else 22.dp
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (m.mine) cs.primaryContainer.copy(alpha = (Prefs.glass + 0.3f).coerceIn(0f, 1f)) else glassColor(0.2f),
            shape = shape, modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                Text(m.body, style = MaterialTheme.typography.bodyLarge)
                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    Text(fmtTime(m.ts), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    if (m.mine) {
                        Spacer(Modifier.width(6.dp))
                        Text(
                            when (m.status) { 0 -> "…"; 1 -> "✓"; else -> "✓✓" },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (m.status == 3) cs.primary else cs.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = MaterialTheme.shapes.extraLarge, color = glassColor(0.15f), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title.uppercase(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val connected by ChatClient.connected.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            withContext(Dispatchers.IO) {
                ctx.contentResolver.openInputStream(uri)?.use { input ->
                    File(ctx.filesDir, "wallpaper.img").outputStream().use { input.copyTo(it) }
                }
            }
            Prefs.update { wallpaper = "image"; wallpaperVersion += 1 }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Wallpaper()
        Column(Modifier.fillMaxSize()) {
            Frosted(top = true) {
                Row(
                    Modifier.statusBarsPadding().padding(horizontal = 4.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    Text("Settings", style = MaterialTheme.typography.titleLarge)
                }
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Section("Theme") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                            FilterChip(
                                selected = Prefs.mode == i, onClick = { Prefs.update { mode = i } },
                                label = { Text(label) }, shape = MaterialTheme.shapes.medium
                            )
                        }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SeedColors.forEach { c ->
                            val selected = Prefs.seed == c && !Prefs.dynamic
                            Box(
                                Modifier.size(40.dp)
                                    .clip(avatarShape()).background(Color(c))
                                    .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, avatarShape()) else Modifier)
                                    .clickable { Prefs.update { seed = c; dynamic = false } }
                            )
                        }
                    }
                    if (Build.VERSION.SDK_INT >= 31) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Use system colours (Material You)", Modifier.weight(1f))
                            Switch(checked = Prefs.dynamic, onCheckedChange = { Prefs.update { dynamic = it } })
                        }
                    }
                }
                Section("Corners") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !Prefs.square, onClick = { Prefs.update { square = false } },
                            label = { Text("Rounded") }, shape = MaterialTheme.shapes.medium
                        )
                        FilterChip(
                            selected = Prefs.square, onClick = { Prefs.update { square = true } },
                            label = { Text("Square") }, shape = MaterialTheme.shapes.medium
                        )
                    }
                }
                Section("Chat wallpaper") {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("plain" to "Plain", "dots" to "Dots", "grid" to "Grid", "aurora" to "Aurora").forEach { (id, label) ->
                            FilterChip(
                                selected = Prefs.wallpaper == id, onClick = { Prefs.update { wallpaper = id } },
                                label = { Text(label) }, shape = MaterialTheme.shapes.medium
                            )
                        }
                        FilterChip(
                            selected = Prefs.wallpaper == "image",
                            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            label = { Text("Photo") },
                            leadingIcon = { Icon(Icons.Filled.ImageIcon, null, Modifier.size(18.dp)) },
                            shape = MaterialTheme.shapes.medium
                        )
                    }
                    Text("Wallpaper blur", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = Prefs.wallpaperBlur, onValueChange = { Prefs.update { wallpaperBlur = it } },
                        valueRange = 0f..25f, enabled = Build.VERSION.SDK_INT >= 31
                    )
                    if (Build.VERSION.SDK_INT < 31) {
                        Text("Blur needs Android 12 or newer.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("Transparency (bars and bubbles)", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = Prefs.glass, onValueChange = { Prefs.update { glass = it } },
                        valueRange = 0.15f..1f
                    )
                }
                Section("Account") {
                    Text(Prefs.email, style = MaterialTheme.typography.titleMedium)
                    Text(
                        Prefs.server + "  ·  " + if (connected) "connected" else "offline",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                ChatClient.stop()
                                AppDb.get(ctx).dao().clear()
                                Prefs.update { token = ""; email = "" }
                            }
                        },
                        shape = MaterialTheme.shapes.large
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Log out")
                    }
                }
            }
        }
    }
}
