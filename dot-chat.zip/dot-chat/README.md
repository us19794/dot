# Dot — Android messenger (MVP)

```
backend/   Node.js + WebSocket server (PostgreSQL)
android/   Kotlin + Jetpack Compose app
```

## 1. Run the backend
You need a PostgreSQL database (free: Neon, Supabase, or Render Postgres).

```
cd backend
npm install
export DATABASE_URL=postgres://user:pass@host:5432/dbname
export JWT_SECRET=$(openssl rand -hex 32)
npm start
```
Tables are created automatically on first start. To host it free for testing, deploy
the `backend` folder on Render or Railway and set the same environment variables
(`PGSSL=true` if your database requires SSL).

Use HTTPS in production. The app allows plain HTTP only so you can test on a LAN.

## 2. Build the APK
Push this repo to GitHub, add `.github/workflows/build.yml`, and run the
"Build APK" workflow. Download `dot-debug-apk` from the run's Artifacts and install it.

## 3. Use it
Open the app, enter your server URL (e.g. `https://dot-server.onrender.com`), create an
account, then tap + and enter another registered email to start chatting.

## Known limits of this MVP
- No FCM push yet: messages arrive while the app process is alive; notifications show
  when the app is in the background but still running.
- No email verification or password reset yet.
- Text only, no end-to-end encryption yet (messages are stored on your server).
- Blur needs Android 12+.
